# SQL-Generator
Generate SQL script with Pandas-like Python code


