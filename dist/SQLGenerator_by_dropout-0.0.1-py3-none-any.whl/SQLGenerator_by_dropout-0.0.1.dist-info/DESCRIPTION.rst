# SQL-Generator
Generate SQL script with Pandas-like Python code

# Install
```bash
pip install https://github.com/drop-out/SQL-Generator/raw/master/dist/SQLGenerator-by-dropout-0.0.1.tar.gz
```


